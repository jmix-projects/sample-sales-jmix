package com.company.samplesales.diagramevents;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_Diagramevents")
@UiDescriptor("diagramEvents.xml")
public class DiagramEvents extends Screen {
}