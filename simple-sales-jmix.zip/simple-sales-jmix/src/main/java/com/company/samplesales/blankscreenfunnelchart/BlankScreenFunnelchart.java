package com.company.samplesales.blankscreenfunnelchart;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenFunnelchart")
@UiDescriptor("blank-screen_funnelChart.xml")
public class BlankScreenFunnelchart extends Screen {
}