package com.company.samplesales.blank_screen_piechart;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenPiechart")
@UiDescriptor("blank-screen_pieChart.xml")
public class BlankScreenPiechart extends Screen {
}