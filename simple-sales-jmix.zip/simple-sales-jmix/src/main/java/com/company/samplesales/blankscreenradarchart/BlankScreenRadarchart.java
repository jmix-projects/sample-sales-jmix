package com.company.samplesales.blankscreenradarchart;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenRadarchart")
@UiDescriptor("blank-screen_radarChart.xml")
public class BlankScreenRadarchart extends Screen {
}