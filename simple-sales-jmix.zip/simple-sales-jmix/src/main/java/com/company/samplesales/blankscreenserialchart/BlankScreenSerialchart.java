package com.company.samplesales.blankscreenserialchart;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenSerialchart")
@UiDescriptor("blank-screen_serialChart.xml")
public class BlankScreenSerialchart extends Screen {
}