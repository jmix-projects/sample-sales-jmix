package com.company.samplesales.blankscreenangulargaugechart;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenAngularGaugechart")
@UiDescriptor("blank-screen_Angular_gaugeChart.xml")
public class BlankScreenAngularGaugechart extends Screen {
}