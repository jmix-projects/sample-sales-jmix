package com.company.samplesales.blank;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreen")
@UiDescriptor("blank-screen.xml")
public class BlankScreen extends Screen {
}