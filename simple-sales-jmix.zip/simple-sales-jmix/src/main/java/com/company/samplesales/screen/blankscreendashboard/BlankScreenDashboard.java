package com.company.samplesales.screen.blankscreendashboard;

import io.jmix.ui.screen.Screen;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("sales_BlankScreenDashboard")
@UiDescriptor("blank-screen-dashboard.xml")
public class BlankScreenDashboard extends Screen {
}